# 📦 EMAIL SCRAPER - DAĞITIM KILAVUZU

## 🎯 Şirkete Nasıl Dağıtılır?

### Yöntem 1: Tek EXE Dosyası (ÖNERİLEN)

#### Adım 1: EXE Oluştur
```bash
build_exe.bat
```

Bu komut:
- `dist\EmailScraper.exe` dosyasını oluşturur (~50-70 MB)
- **Python yüklü olmayan** bilgisayarlarda da çalışır
- Tüm bağımlılıkları içerir

#### Adım 2: Dağıt
`dist` klasöründen şunları kopyalayın:
- ✅ `EmailScraper.exe` (Ana program)
- ✅ `KULLANIM.md` (Kullanım kılavuzu)
- ✅ `YENI_OZELLIKLER.md` (Özellikler listesi)

#### Adım 3: Paylaş
Bu dosyaları:
- 📧 Email ile gönderin
- 💼 Şirket network klasörüne koyun
- ☁️ SharePoint/OneDrive'a yükleyin
- 💾 USB ile dağıtın

### Yöntem 2: Python ile Çalıştırma

Eğer Python yüklüyse:

1. **Tüm klasörü kopyalayın:**
   ```
   email-scraper/
   ├── gui.py
   ├── config.py
   ├── excel_handler.py
   ├── email_extractor.py
   ├── web_scraper.py
   ├── page_detector.py
   ├── requirements.txt
   └── Email_Scraper_Baslat.bat
   ```

2. **Bağımlılıkları yükleyin:**
   ```bash
   python -m pip install -r requirements.txt
   ```

3. **Çalıştırın:**
   ```bash
   Email_Scraper_Baslat.bat
   ```
   veya
   ```bash
   python gui.py
   ```

---

## 🖥️ Sistem Gereksinimleri

### EXE Versiyonu:
- ✅ Windows 7/8/10/11 (64-bit)
- ✅ Python YÜKLENMESİNE GEREK YOK
- ✅ 100 MB boş disk alanı
- ✅ İnternet bağlantısı (web tarama için)

### Python Versiyonu:
- ✅ Python 3.8 veya üzeri
- ✅ Windows/Mac/Linux

---

## 📋 Kullanıcı İçin Talimatlar

### İlk Kurulum

#### EXE ile:
1. `EmailScraper.exe` dosyasını masaüstüne kopyalayın
2. Çift tıklayın
3. Hemen kullanmaya başlayın!

#### Python ile:
1. `Email_Scraper_Baslat.bat` dosyasına çift tıklayın
2. Gerekli kütüphaneler otomatik yüklenecek
3. Program otomatik açılacak

### Kullanım

1. **📁 Excel Seç** → 3 sayfalı Excel dosyanızı seçin
2. **❓ Nasıl Kullanılır?** → Kullanım kılavuzunu açar
3. **📥 Örnek Excel İndir** → Boş template indirir
4. **▶️ Analizi Başlat** → İşlemi başlatır
5. **⏸️ Durdur** → İşlemi iptal eder

### Çıktı

Program şunları oluşturur:
- 📄 `dosyaadi_sonuc.xlsx` → Tüm sayfalarla birlikte sonuç
- 📝 `email_scraper.log` → Detaylı log dosyası

---

## 🔒 Güvenlik Notları

### Antivirüs Uyarıları
PyInstaller ile oluşturulan EXE dosyaları bazı antivirüs programları tarafından yanlış pozitif verebilir:

**Çözüm:**
1. Dosyayı güvenli listesine ekleyin
2. IT departmanına bildirin
3. Kod açık kaynak - inceletilebilir

### Network Güvenliği
Program:
- ✅ Sadece Excel'deki website'leri ziyaret eder
- ✅ Email adresi dışında veri toplamaz
- ✅ Hiçbir veriyi dışarı göndermez
- ✅ Tüm işlemler local bilgisayarda yapılır

---

## 📊 Test Önerileri

### Dağıtımdan Önce Test Edin:

1. **Temiz Bilgisayarda Test:**
   - Python yüklü olmayan bir PC'de deneyin
   - EXE'nin çalıştığından emin olun

2. **Örnek Excel ile Test:**
   ```bash
   EmailScraper.exe
   # "Örnek Excel İndir" butonuna tıklayın
   # İndirilen dosyayı işleyin
   ```

3. **Gerçek Veri ile Test:**
   - 3 sayfalı Excel dosyanızı test edin
   - Her 3 sayfanın da işlendiğini doğrulayın

---

## 💡 Kullanıcı Eğitimi

### Email veya Toplantıda Paylaşılacak Bilgiler:

```
Merhaba,

Yeni Email Scraper aracını kullanmaya başlayabilirsiniz!

📥 NEREDEN İNDİREBİLİRİM?
[Network klasörü yolu veya SharePoint linki]

🚀 NASIL KULLANIRIM?
1. EmailScraper.exe dosyasını çalıştırın
2. Excel dosyanızı seçin (çok sayfalı destekleniyor!)
3. "Analizi Başlat" butonuna tıklayın
4. İşlem bitince sonuç dosyası otomatik kaydedilir

📋 EXCEL FORMATI
Excel'inizde şu kolonlar olmalı:
- Firma Adı
- Websites (zorunlu)
- Email (boş olan satırlar için email bulunur)
- Diğer kolonlar (opsiyonel)

💡 İPUCU
"Nasıl Kullanılır?" butonuna tıklayarak detaylı kılavuza ulaşabilirsiniz.

❓ SORULARINIZ İÇİN
[İletişim bilginiz]
```

---

## 🛠️ Sorun Giderme

### "EXE çalışmıyor"
- Windows Defender'ı geçici kapatın
- Dosyayı sağ tıklayıp "Yönetici olarak çalıştır" deneyin
- `email_scraper.log` dosyasını kontrol edin

### "Çok yavaş çalışıyor"
- Normal! Her website ziyaret edilir (10-30 saniye per site)
- 50 firma için ~10-20 dakika
- İnternet hızınıza bağlı

### "Hiç email bulamadı"
- %50-60 başarı oranı normaldir
- Bazı siteler email paylaşmıyor
- Bot koruması engelleyebilir

---

## 📞 Destek

### Hata Raporlama:
Sorun yaşarsanız şunları gönderin:
1. `email_scraper.log` dosyası
2. Kullandığınız Excel dosyası (örnek)
3. Hata ekran görüntüsü

---

## 🎉 Başarılı Dağıtım Checklist

- [ ] EXE oluşturuldu (`build_exe.bat`)
- [ ] Temiz PC'de test edildi
- [ ] Dokümantasyon hazırlandı
- [ ] Network klasörüne yüklendi
- [ ] Kullanıcılara email gönderildi
- [ ] Örnek kullanım gösterildi
- [ ] Destek kanalı belirlendi

---

## 📦 Dağıtım Paketi İçeriği

Kullanıcılara şunları verin:

```
📦 EmailScraper_v1.0/
  ├── 📄 EmailScraper.exe (Ana program)
  ├── 📖 KULLANIM.md (Kullanım kılavuzu)
  ├── ✨ YENI_OZELLIKLER.md (Özellikler)
  └── 📋 DAGITIM_KILAVUZU.md (Bu dosya)
```

**Toplam Boyut:** ~70-80 MB

---

## 🔄 Güncelleme Nasıl Yapılır?

Yeni versiyon çıktığında:

1. Yeni EXE oluşturun: `build_exe.bat`
2. Versiyon numarasını değiştirin
3. Eski dosyayı yedekleyin
4. Yeni dosyayı dağıtın
5. Kullanıcılara bildirin

---

**✅ Artık hazırsınız! Ekibiniz email scraper'ı kullanabilir.**
