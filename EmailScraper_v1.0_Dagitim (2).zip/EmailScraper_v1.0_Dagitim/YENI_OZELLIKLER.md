# 🎉 Email Scraper - YENİ ÖZELLİKLER EKLENDI

## ✨ Eklenen Özellikler

### 1. ❓ Nasıl Kullanılır Butonu
- GUI'de sağ üstte "Nasıl Kullanılır?" butonu eklendi
- Tıkladığınızda detaylı kullanım kılavuzu açılır
- İçeriği:
  - Excel dosya yapısı açıklaması
  - Program özellikleri
  - Adım adım kullanım talimatları
  - İpuçları ve öneriler
  - Sık Sorulan Sorular

### 2. 📥 Örnek Excel İndir Butonu
- Doğru formatta örnek Excel dosyası oluşturur
- 3 örnek firma verisi içerir
- Tüm gerekli kolonları içerir:
  - Firma Adı
  - Adres
  - Telefon
  - Websites ⚠️ (zorunlu - email bulunsun isterseniz)
  - Sektör
  - Email (program buraya email yazacak)
  - googleMapsURL

### 3. 🗂️ Multi-Sheet Excel Desteği
- **BÜYÜK YENİLİK!** Birden fazla sayfa içeren Excel dosyalarını destekler
- Örnek: 
  - Giriş Excel: 3 sayfa (İstanbul, Ankara, İzmir)
  - Çıkış Excel: 3 sayfa (aynı yapı korunur)
- Her sayfa ayrı ayrı işlenir
- Çıktı dosyası giriş dosyası ile aynı yapıyı korur

## 🧪 Test Dosyaları

### MULTISHEET_TEST.xlsx
Çok sayfalı test için oluşturuldu:
- **İstanbul sayfası**: 3 firma
- **Ankara sayfası**: 2 firma
- **İzmir sayfası**: 3 firma
- **TOPLAM**: 8 firma, 3 sayfa

## 🚀 Nasıl Test Edilir?

### 1. Yardım Sistemini Test Et
```bash
python gui.py
```
1. Program açıldığında sağ üstteki **"❓ Nasıl Kullanılır?"** butonuna tıkla
2. Açılan pencerede kullanım kılavuzunu oku
3. Pencereyi kapat

### 2. Template İndirmeyi Test Et
1. **"📥 Örnek Excel İndir"** butonuna tıkla
2. Dosya kaydetme penceresi açılır
3. İstediğin yere kaydet (örn: ornek_template.xlsx)
4. Excel'de aç ve yapısına bak

### 3. Multi-Sheet İşlemeyi Test Et
1. **"📁 Excel Seç"** butonuna tıkla
2. `MULTISHEET_TEST.xlsx` dosyasını seç
3. **"▶️ Analizi Başlat"** butonuna tıkla
4. Program tüm 3 sayfayı işleyecek:
   - İstanbul (3 firma)
   - Ankara (2 firma)
   - İzmir (3 firma)
5. Çıktı dosyası `MULTISHEET_TEST_sonuc.xlsx` olarak kaydedilir
6. Çıktı dosyasını aç ve 3 sayfa olduğunu kontrol et

## 📊 Beklenen Sonuç

### Log Ekranında Görecekleriniz:
```
🔍 Excel'de 3 sayfa bulundu: ['İstanbul', 'Ankara', 'İzmir']

📄 'İstanbul' sayfası işleniyor... (1/3)
   ⏳ İşlenecek website sayısı: 3

   🔍 ABC Tech websitesi taranıyor: https://www.example.com
   ...

📊 'İstanbul' Sayfası Özeti:
   ✅ Email bulundu: X
   ❌ Bulunamadı: Y

📄 'Ankara' sayfası işleniyor... (2/3)
   ...

📄 'İzmir' sayfası işleniyor... (3/3)
   ...

✅ TÜM SAYFALAR TAMAMLANDI!

📊 GENEL ÖZET:
   📄 İşlenen sayfa sayısı: 3
   🏢 Toplam firma sayısı: 8
   ✅ Email bulundu: X
   ❌ Bulunamadı: Y
   🎯 Başarı oranı: %XX
```

## 🎯 Özellik Özeti

| Özellik | Durum | Açıklama |
|---------|-------|----------|
| 8-Katmanlı Email Tarama | ✅ | Agresif tarama sistemi |
| 11 Dil Desteği | ✅ | Çok dilli iletişim sayfası algılama |
| CloudFlare Çözme | ✅ | Şifrelenmiş email'leri çözebilir |
| Akıllı Filtreleme | ✅ | Junk email'leri temizler |
| GUI | ✅ | Kullanıcı dostu arayüz |
| İlerleme Takibi | ✅ | Gerçek zamanlı progress bar |
| Log Görüntüleme | ✅ | Canlı log ekranı |
| Yardım Sistemi | ✅ **YENİ** | Nasıl kullanılır popup |
| Template İndirme | ✅ **YENİ** | Örnek Excel oluşturma |
| Multi-Sheet Desteği | ✅ **YENİ** | Çoklu sayfa işleme |

## ⚡ Hızlı Başlangıç

Windows'ta tek tıkla başlat:
```
Email_Scraper_Baslat.bat
```

Manuel başlatma:
```bash
python gui.py
```

## 📝 Notlar

- Multi-sheet Excel dosyalarında her sayfa ayrı işlenir
- Çıktı dosyası giriş ile aynı sayfa yapısına sahiptir
- Her sayfa için ayrı istatistik gösterilir
- Son olarak genel özet gösterilir
- Eğer bir sayfada tüm email'ler zaten doluysa o sayfa atlanır

## 🐛 Sorun Giderme

### GUI açılmıyor
```bash
python -m pip install -r requirements.txt
python gui.py
```

### Multi-sheet çalışmıyor
- Excel dosyanızın geçerli bir .xlsx dosyası olduğundan emin olun
- Her sayfanın aynı kolon yapısına sahip olduğundan emin olun

## 📞 Destek

Herhangi bir sorunla karşılaşırsanız:
1. "❓ Nasıl Kullanılır?" butonuna tıklayın
2. Sık Sorulan Sorular bölümünü kontrol edin
3. Log ekranındaki hata mesajlarını okuyun
