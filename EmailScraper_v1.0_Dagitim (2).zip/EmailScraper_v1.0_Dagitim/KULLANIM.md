# 📧 Email Scraper - Kullanım Kılavuzu

## 🚀 Hızlı Başlangıç

### Adım 1: GUI'yi Başlatın
```bash
python gui.py
```

### Adım 2: Excel Dosyanızı Seçin
- "Dosya Seç" butonuna tıklayın
- Business lead'lerinizi içeren Excel dosyasını seçin
- Otomatik olarak çıkış dosyası adı oluşturulur

### Adım 3: Analizi Başlatın
- "🚀 Analizi Başlat" butonuna tıklayın
- Program her firmayı sırayla tarar
- İlerleme çubuğunda durumu görebilirsiniz

### Adım 4: Sonuçları İndirin
- İşlem bittiğinde sonuçlar otomatik kaydedilir
- "Dosyayı Aç" diyerek Excel'i açabilirsiniz

## 📋 Excel Formatı

Program şu sütunları arar:

| Sütun Adı | Açıklama |
|-----------|----------|
| Firma Adı | Şirket ismi |
| Adres | Adres bilgisi |
| Telefon | Telefon numarası |
| **Websites** | **Website URL'i (zorunlu)** |
| Sektör | İş sektörü |
| **Email** | **Email adresi (program buraya yazacak)** |
| googleMapsURL | Google Maps linki |

⚠️ **ÖNEMLİ:** 
- `Websites` sütunu dolu olmalı
- `Email` sütunu boş olanlar taranır
- Zaten email olan satırlar atlanır

## 🎯 Özellikler

### ✨ Ultra Agresif Email Bulma
- ✅ Ana sayfa tarama
- ✅ İletişim sayfası tarama
- ✅ Hakkımızda sayfası tarama
- ✅ mailto: linkleri
- ✅ Form field'ları
- ✅ JavaScript'te gömülü email'ler
- ✅ CloudFlare korumalı email'ler
- ✅ HTML attribute'ları
- ✅ HTML yorumları

### 🌍 Çok Dilli Destek
11 dilde iletişim sayfası bulma:
- Türkçe, İngilizce, Fransızca, Almanca, İspanyolca
- İtalyanca, Arapça, Portekizce, Hollandaca, Lehçe, Rusça

### 🛡️ Akıllı Filtreleme
- Gmail, Hotmail gibi kişisel email'leri atlar
- Sadece kurumsal email'leri bulur
- Spam/junk email'leri filtreler

## 📊 GUI Özellikleri

### İlerleme Takibi
- Gerçek zamanlı ilerleme çubuğu
- Her firma için durum gösterimi
- Anlık istatistikler

### Canlı Log
- Her adımı görebilirsiniz
- Hangi email'lerin bulunduğunu görürsünüz
- Hata mesajları anında gösterilir

### Durdurma Özelliği
- İstediğiniz zaman durdurun
- O ana kadar bulunan email'ler kaydedilir

## 💡 İpuçları

### En İyi Sonuçlar İçin
1. **Website URL'leri tam olsun** → `https://example.com`
2. **Çok fazla satır varsa** → Küçük gruplar halinde test edin
3. **Yavaş internet bağlantısı** → Sabırlı olun, her site 10-15 saniye sürebilir

### Sorun Giderme

**"Email bulunamadı" çok fazla çıkıyor**
- Bazı siteler email paylaşmıyor (sadece form var)
- Bot koruması olan siteler engelliyor
- Email gerçekten sitede yok olabilir

**Program dondu gibi görünüyor**
- Normal! Bazı siteler yavaş yüklenir
- Log bölümünde ilerlemeyi kontrol edin

**Junk email'ler bulunuyor**
- Blacklist sürekli güncelleniyor
- Çok spam gelirse bildirin

## 🎨 Ekran Görüntüleri

### Ana Ekran
```
┌─────────────────────────────────────────────┐
│  📧 Email Scraper - Business Lead Finder    │
│  Website'lerden otomatik email adresi bulma │
├─────────────────────────────────────────────┤
│  📁 Dosya Seçimi                            │
│  Excel Dosyası: [test.xlsx]    [Dosya Seç] │
│  Çıkış Dosyası: [test_emails_20260120.xlsx]│
├─────────────────────────────────────────────┤
│  [🚀 Analizi Başlat]  [⏹ Durdur]           │
├─────────────────────────────────────────────┤
│  📊 İlerleme                                │
│  ▓▓▓▓▓▓▓▓▓▓░░░░░░░░░ 56%                   │
│  Taranıyor: GELEC Energy... (9/16)          │
│  ✅ Bulundu: 5  ❌ Bulunamadı: 4  📋 Toplam: 16 │
├─────────────────────────────────────────────┤
│  📝 İşlem Detayları                         │
│  [Log mesajları buradan akıyor...]          │
└─────────────────────────────────────────────┘
```

## 🔧 Gelişmiş Kullanım

### Komut Satırı
GUI kullanmak istemiyorsanız:

```bash
python main.py input.xlsx output.xlsx
```

### Toplu İşlem
Birden fazla dosya için:

```bash
for /f %i in ('dir /b *.xlsx') do python main.py %i output_%i
```

## 📞 Destek

Sorun yaşarsanız:
1. `email_scraper.log` dosyasını kontrol edin
2. Hata mesajını not edin
3. Örnek Excel dosyası ile test edin

## 🎉 Başarı Hikayeleri

**Ortalama Başarı Oranı:** %50-60
- 10 firmadan 5-6'sında email bulunur
- İletişim sayfası olan sitelerde %80+
- Sadece form olan sitelerde %20-30
