# EMAIL SCRAPER v1.0

## Hizli Baslangic

1. **EmailScraper.exe** dosyasina cift tiklayin
2. Excel dosyanizi secin
3. "Analizi Baslat" butonuna tiklayin
4. Sonuc dosyasi otomatik kaydedilir

## Dokumantasyon

- **KULLANIM.md** - Detayli kullanim kilavuzu
- **YENI_OZELLIKLER.md** - Ozellikler listesi
- **DAGITIM_KILAVUZU.md** - IT icin teknik bilgiler

## Sistem Gereksinimleri

- Windows 7/8/10/11 (64-bit)
- Python yuklenmesine gerek YOK
- Internet baglantisi

## Destek

Sorun yasarsaniz email_scraper.log dosyasini kontrol edin.

